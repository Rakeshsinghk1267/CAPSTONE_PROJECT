const express = require("express");
const path = require("path");
const router = express.Router();

const mongoose = require("mongoose");

// app.use(bodyParser.json());
const Restaurents = require("../modals/restaurent.js");
const newfooditemsData = require('../modals/newfooditems_schema.js');
const customerorders = require('../modals/customerorder.js');

const urlencoded = require("body-parser/lib/types/urlencoded");
const { post } = require("./LoginControllers.js");
mongoose
  .connect(
    "mongodb+srv://fow:fow@cluster0.p3fge.mongodb.net/Foodwebsite?retryWrites=true&w=majority",
    {
      useUnifiedTopology: true,
      useNewUrlParser: true,
    }
  )
  .then(() => {
    console.log("Successfully Connected To MongoDB Database.");
  })
  .catch((e) => {
    console.log("Not Connected To MongoDB Database.");
  });

const connection = mongoose.connection;

// app.use(express.json());
// app.use(express.urlencoded({ extended: false }));
// const bodyParser = require("body-parser");

router.get("/getrestaurentsData", function (req, res) {
  Restaurents.find({}, function (err, docs) {
    if (err) {
      console.log(err);
    } else {
      // console.log(docs);
      res.send(docs);
    }
  });
});

router.get("/getcustomerorders", function (req, res) {
  customerorders.find({}, function (err, docs) {
    if (err) {
      console.log(err);
    } else {
      console.log(docs);
      res.send(docs);
    }
  });
});

router.get("/getnewfooditemsdata", function (req, res) {
  newfooditemsData.find({}, function (err, docs) {
    if (err) {
      console.log(err);
    } else {
      console.log(docs);
      res.send(docs);
    }
  });
});



router.post('/sendnewfooditems', function(req,res){
  //  res.sendFile(__dirname + '/pages/app-profile.html');
  // console.log(req.body);
  var obj = new newfooditemsData({
      Food_name:req.body.Food_name,
      description:req.body.description,
      Amount:req.body.Amount,
      category:req.body.category,
      sub_category:req.body.sub_category,
      quantity:req.body.quantity,
  })
  obj.save(function(err, results) {
      if(results){
            res.send(results);
            console.log(results);
      }else{
          console.log(err)
          res.send(err);
      }
  })

});








module.exports = router;
